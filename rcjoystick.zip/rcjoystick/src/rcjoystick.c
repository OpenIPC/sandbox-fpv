/**
 * modifled for mavlink udp socket by whoim@mail.ru
 *
 * Author: Jason White
 *
 * Description:
 * Reads joystick/gamepad events and displays them.
 *
 * Compile:
 * gcc joystick.c -o joystick
 *
 * Run:
 * ./joystick [/dev/input/jsX]
 *
 * See also:
 * https://www.kernel.org/doc/Documentation/input/joystick-api.txt
 */
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <linux/joystick.h>
#include <sys/socket.h>
#include <errno.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "common/mavlink.h"

#define BUFFER_LENGTH 2041 // minimum buffer size that can be used with qnx (I don't know why)

const char addr[] = "127.0.0.1";
const int port = 14549;
#define SEND_TIME 50 //in milliseconds
#define AXS_COUNT 5

struct sockaddr_in sin_out = {
    .sin_family = AF_INET,
};
int out_sock;
int errsv;

/**
 * Reads a joystick event from the joystick device.
 *
 * Returns 0 on success. Otherwise -1 is returned.
 */
int read_event(int fd, struct js_event *event)
{
    ssize_t bytes;

    bytes = read(fd, event, sizeof(*event));
    errsv = errno;
    if (bytes == sizeof(*event))
        return 0;

    /* Error, could not read full event. */
    return -1;
}

/**
 * Returns the number of axes on the controller or 0 if an error occurs.
 */
size_t get_axis_count(int fd)
{
    __u8 axes;

    if (ioctl(fd, JSIOCGAXES, &axes) == -1)
        return 0;

    return axes;
}

/**
 * Returns the number of buttons on the controller or 0 if an error occurs.
 */
size_t get_button_count(int fd)
{
    __u8 buttons;
    if (ioctl(fd, JSIOCGBUTTONS, &buttons) == -1)
        return 0;

    return buttons;
}

/**
 * Current state of an axis.
 */
struct axis_state {
    short x, y;
};

/**
 * Keeps track of the current axis state.
 *
 * NOTE: This function assumes that axes are numbered starting from 0, and that
 * the X axis is an even number, and the Y axis is an odd number. However, this
 * is usually a safe assumption.
 *
 * Returns the axis that the event indicated.
 */
size_t get_axis_state(struct js_event *event, struct axis_state axes[3])
{
    size_t axis = event->number / 2;

    if (axis < AXS_COUNT)
    {
        if (event->number % 2 == 0)
            axes[axis].x = event->value;
        else
            axes[axis].y = event->value;
    }

    return axis;
}

long long millis() {
    struct timeval te; 
    gettimeofday(&te, NULL); // get current time
    long long milliseconds = te.tv_sec*1000LL + te.tv_usec/1000; // calculate milliseconds
    // printf("milliseconds: %lld\n", milliseconds);
    return milliseconds;
}

uint16_t axes_to_ch(int16_t val, uint16_t add) {
    return ((32768 + val) / 65.535) + add;
}

int main(int argc, char *argv[])
{
  const char *device;
  int js;
  struct js_event event;
  struct axis_state axes[AXS_COUNT] = {0};
  size_t axis;

  if (argc > 1)
    device = argv[1];
  else
    device = "/dev/input/js0";
    

  while (true) { //loop
    js = open(device, O_RDONLY | O_NONBLOCK);

    if (js == -1) {
        perror("Could not open joystick");
        close(js);
        errsv = errno;
        printf("open result: %d\n", errsv);
        sleep (1);
        continue;
        //return 0;
    }

    /* This loop will exit if the controller is unplugged. */
    
    //udp sock
    uint8_t buf[BUFFER_LENGTH];
    mavlink_message_t msg;
    uint16_t len;
    int bytes_sent;
    out_sock = socket(AF_INET, SOCK_DGRAM, 0);
    inet_aton(addr, &sin_out.sin_addr);
    sin_out.sin_port = htons(port);
    int buttons[6];
    
    long long time_check = millis();
    
    do
    {
     read_event(js, &event);
     switch (event.type)
        {
            case JS_EVENT_BUTTON:
                printf("Button %u %s\n", event.number, event.value ? "pressed" : "released");
                buttons[event.number] = event.value ? 2000 : 1000;
                break;
            case JS_EVENT_AXIS:
                axis = get_axis_state(&event, axes);
                if (axis < AXS_COUNT)
                    printf("Axis %zu at (%6d, %6d)\n", axis, axes[axis].x, axes[axis].y);
                break;
            default:
                // Ignore init events.
                break;
        }
        
        if( (long long)time_check + SEND_TIME < millis() ){
            mavlink_msg_rc_channels_override_pack(255, 190, &msg, 0, 0, axes_to_ch(axes[1].x, 1000), axes_to_ch(axes[1].y, 1000), axes_to_ch(axes[0].x, 1000), axes_to_ch(axes[0].y, 1000), axes_to_ch(axes[2].x, 1000), axes_to_ch(axes[2].y, 1000), axes_to_ch(axes[3].x, 1000), axes_to_ch(axes[3].y, 1000), axes_to_ch(axes[4].x, 1000), axes_to_ch(axes[4].y, 1000), buttons[0], buttons[1], buttons[2], buttons[3], buttons[4], buttons[5], buttons[6], buttons[7]);
            len = mavlink_msg_to_send_buffer(buf, &msg);
            bytes_sent = sendto(out_sock, buf, len, 0, (struct sockaddr *)&sin_out, sizeof(sin_out));
            printf("Sent %d bytes\n", bytes_sent);
            time_check = millis();
        }
        //printf("%lld, %lld\n",time_check, millis());
        //printf("read result: %d\n", errsv);
        fflush(stdout);
    } while (errsv == 11 || errsv == 38); //while no err
    
    close(js);
  } //while true
}
